function closeNewApplicationWindow() {
	window.opener.location.href=window.opener.location.href;
	window.close();
}
function openNewAppWindow(type) {
	window.open("NewApplication.aspx?type="+type, "NewApplication", "location=no,menubar=no,width=750,height=600,toolbar=no,resizable=yes,scrollbars=yes");
}
function printAppList(list) {
	window.open("MyCollegeList.aspx?section="+list+"&action=print", "Print", "location=no,menubar=no,width=750,height=600,toolbar=no,resizable=yes,scrollbars=yes");
}
function openAppDetails(appId) {
	window.open("ApplicationDetails.aspx?app="+appId, "ApplicationDetails", "location=no,menubar=no,width=450,height=400,toolbar=no,resizable=yes,scrollbars=yes");
}
function openAppDet(type, appId) {
	var width = 450, height = 400;
	switch(type) {
		case "AdmissionDetails":
			height = 480;
			width = 470;
		break;
		case "AdmitRequirements":
			height = 600;
			width = 580;
		break;
		case "FinancialAid":
			height = 600;
			width = 540;
		break;
	}
	window.open("ApplicationDetails.aspx?type="+type+"&app="+appId, "ApplicationDetails", "location=no,menubar=no,width="+width+",height="+height+",toolbar=no,resizable=yes,scrollbars=yes");
}
function openComments(appId, collegeId) {
	window.open("Comments.aspx?app="+appId+"&college="+collegeId, "Comments", "location=no,menubar=no,width=540,height=550,toolbar=no,resizable=yes,scrollbars=yes");
}
function printLabels() {
	window.open("PrintLabels.ashx?action=print", "Print", "location=no,menubar=no,width=750,height=600,toolbar=no,resizable=yes,scrollbars=yes");
}
function printPage(page) {
	window.open("Print.aspx?page="+page+"&action=print", "Print", "location=no,menubar=no,width=850,height=600,toolbar=no,resizable=yes,scrollbars=yes");
}
function printAppProgress(useCurrentState) {
	var showAll = '', show = '';
	if (useCurrentState) {
		show = $("input[name$='hdSelection']").val();
		show = "selection=" + show + "&";
	} else {
		showAll = "all=1&";
	}
	var page = "MyApplicationProgress";
	var view = $("input[name$='hdView']").val();
	window.open("Print.aspx?page=" + page + "&view=" + view + "&action=print&" + showAll + show, "Print", "location=no,menubar=no,width=850,height=600,toolbar=no,resizable=yes,scrollbars=yes");
}

Sys.Application.add_load(AppLoad);

function AppLoad() {
	Sys.WebForms.PageRequestManager.getInstance().add_endRequest(EndRequest);
	Sys.WebForms.PageRequestManager.getInstance().add_initializeRequest(CheckStatus);
}
 
function EndRequest(sender, args) {
	if (args.get_error() != undefined) {
		args.set_errorHandled(true);
	}
}
function CheckStatus(sender, args) {
	AbortPostBack();
}

function AbortPostBack() {
	var prm = Sys.WebForms.PageRequestManager.getInstance();
	if (prm.get_isInAsyncPostBack()) {
		prm.abortPostBack();
	}
}

window.onunload = function() {
	AbortPostBack();
}